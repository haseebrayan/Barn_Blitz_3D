﻿using System;

namespace AssemblyCSharp
{
	public class Rotate
	{
		public Rotate ()
		{
		}
	}
}

