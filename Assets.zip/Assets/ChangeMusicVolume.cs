﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ChangeMusicVolume : MonoBehaviour {
	public Slider Volume;
	public AudioSource MyMusic;
void update () {

	MyMusic.volume = Volume.value;

}
}