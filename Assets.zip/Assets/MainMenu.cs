﻿//**********************************
//Michael Dineen April 2018 Group D
//*******************************8**
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;



public class MainMenu : MonoBehaviour {
	
	public Slider Volume;
	public AudioSource MyMusic;
    float rgbValue = 0.5f;
	public Slider Bright;
	public GameObject SettingsMenuHolder;
	public Toggle FullscreenToggle;
	public Toggle[] resolutionToggles;
	public int[] ScreenWidths; 
	int activeScreenResIndex;


	void Start(){
		activeScreenResIndex = PlayerPrefs.GetInt ("screen res index");
		bool isFullscreen = (PlayerPrefs.GetInt ("Fullscreen")==1)?true:false;
	
		for (int i = 0; i < resolutionToggles.Length; i++) {
			resolutionToggles [i].isOn = i == activeScreenResIndex;
		}
		FullscreenToggle.isOn = isFullscreen; 
	}


	public void PlayGame() {

		SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex + 1);
	
	}

	void onGUI(){
		rgbValue = GUI.HorizontalSlider (new Rect(Screen.width/2 - 50, 90, 100, 30), rgbValue, 0f,1.0f);
		RenderSettings.ambientLight = new Color (rgbValue,rgbValue,rgbValue,1);
	}

	void update () {

		MyMusic.volume = Volume.value;

		transform.Rotate (new Vector3 (0, Time.deltaTime * 40, 0));
			
		}
		

	public void QuitGame() {

		Debug.Log ("Quit");
		Application.Quit ();
	
	}

	public void SetScreenResolution(int i){

		if (resolutionToggles [i].isOn) {
			activeScreenResIndex = i;
			float aspectRatio = 16 / 9f;
			Screen.SetResolution (ScreenWidths[i], (int)(ScreenWidths [i] / aspectRatio), false);
			PlayerPrefs.SetInt ("screen res index", activeScreenResIndex);
			PlayerPrefs.Save ();
		}
	}

	public void SetFullscreen(bool isFullscreen){

		for (int i = 0; i < resolutionToggles.Length; i++) {
			resolutionToggles [i].interactable = !isFullscreen;

		}
		if (isFullscreen) {
			Resolution[] allResolutions = Screen.resolutions;
			Resolution maxResolution = allResolutions [allResolutions.Length - 1];
			Screen.SetResolution (maxResolution.width, maxResolution.height, true);
			PlayerPrefs.SetInt ("screen res index", activeScreenResIndex);
			PlayerPrefs.Save ();

		} else {
			SetScreenResolution (activeScreenResIndex);
		}

		PlayerPrefs.SetInt ("Fullscreen", ((isFullscreen) ? 1 : 0));
		PlayerPrefs.Save();
	
	}
}
